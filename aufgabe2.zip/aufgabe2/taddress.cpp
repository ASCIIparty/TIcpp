#include <iostream>
#include <string>
#include "taddress.h"

using namespace std;
TAddress::TAddress()
{

}
TAddress::TAddress(string Street, string Number, string Zipcode, string Town)
{
    this->Street=Street;
    this->Number=Number;
    this->Zipcode=Zipcode;
    this->Town=Town;
}
void TAddress::set_Street(string Street)
{
    this->Street=Street;
}
void TAddress::set_Number(string Number)
{
    this->Number=Number;
}
void TAddress::set_Zipcode(string Zipcode)
{
    this->Zipcode=Zipcode;
}
void TAddress::set_Town(string Town)
{
    this->Town=Town;
}

string TAddress::get_Street()
{
    return Street;
}
string TAddress::get_Number()
{
    return Number;
}
string TAddress::get_Zipcode()
{
    return Zipcode;
}

string TAddress::get_Town()
{
    return Town;
}
void TAddress::print()
{

}


