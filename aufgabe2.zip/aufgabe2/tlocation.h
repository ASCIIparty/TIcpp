#pragma once
#include <iostream>
#include <string>
using namespace std;
class TLocation
    {
        private:
            string Section;
            string Rack;


        public:
            TLocation();
            TLocation(string Section, string Rack);
            void set_Section(string Section);
            void set_Rack(string Rack);
            string get_Section();
            string get_Rack();
            void print();
    };
