#include <iostream>
#include <string>
#include "tlocation.h"

using namespace std;
TLocation::TLocation()
{
    Section= "B�ro";
    Rack= "Fachzum Einsortieren";
}
TLocation::TLocation(string Section, string Rack)
{
    this->Section=Section;
    this->Rack=Rack;
}
void TLocation::set_Section(string Section)
{
    this->Section=Section;
}
void  TLocation::set_Rack(string Rack)
{
    this->Rack=Rack;
}
string  TLocation::get_Section()
{
    return Section;
}
string  TLocation::get_Rack()
{
    return Rack;
}
void TLocation::print()
{

}
